
usuario = "alumno"
contraseña = "python123"
intentos = 3
login_ok = False

for i in range (intentos):
 user = input("introducza su usuario: ")
 pswd = input("introduzca su contraseña: ")
 if user == usuario and pswd == contraseña :
  login_ok = True
  print ("bienvenido")
  break
 else:
  print("usuario o contraseña incorrectos, reintente")

if not login_ok:
 print("cuenta bloqueada, demasiados intentos")

while True:
 opcion = input("opción 1: ver estado de inscripción/ opción 2: cambiar clave/ opción 3: mostras mensaje motivacional/ opción 4: salir/ elija una opción: " )

 while not opcion.isdigit() or int(opcion) < 1 or int(opcion) > 4:
    print("opción invalida")
    opcion = input("elija: ")
 
 
 if opcion == "1": 
   print("usted está inscripto")
 elif opcion == "2":
     contraseña_nueva = input("cambie su contraseña: ")
     contraseña_cambiada = input("confirme contraseña: ")
     while len(contraseña_nueva) < 6 or contraseña_nueva != contraseña_cambiada :
      if len(contraseña_nueva) < 6:
        print("la contraseña debe tener al menos 6 caracteres")
      if  contraseña_nueva != contraseña_cambiada :
       print("las contraseñas no coinciden")
      contraseña_nueva = input("cambie su contraseña: ")
      contraseña_cambiada = input("confirme contraseña: ")
     if contraseña_nueva == contraseña_cambiada:
      print("contraseña cambiada")
 elif opcion == "3":
   print("'La esperanza es el primer paso inevitable en el camino a la decepción'")
 elif opcion == "4":
   print("salió del programa, muchas gracias")
   break