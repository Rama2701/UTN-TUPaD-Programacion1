lunes1 = "josefina"
lunes2 = ""
lunes3 = "juan"
lunes4 = "ramiro"
martes1= ""
martes2= ""
martes3= "nahuel"
nombre = input("hola operador/a, diga su nombre ")
while not nombre.isalpha():
 print("error, solo letras")
 nombre = input("diga su nombre de operador/a: ")
 
print(f"bienvenido operdaor/a {nombre}")
while True:
 opcion = input("opción 1: reserva turno/ opción 2: cancelar turno/ opción 3: ver agenda del día/ opción 4: ver resume general/ opción 5: cerrar sistema  " )
 while not opcion.isdigit() or int(opcion) < 1 or int(opcion) > 5:
     print("opción invalida")
     opcion = input("elija nuevamente dentro de las opciones: opción 1: reserva turno/ opción 2: cancelar turno/ opción 3: ver agenda del día/ opción 4: ver resume general/ opción 5: cerrar sistema ")
 if opcion == "1": 
    dias = input("elija el día a reservar: 1/lunes o 2/martes ")
    while not dias.isdigit() or int(dias) < 1 or int(dias) > 2:
       print("por favor elija dentro de los días validos")
       dias = input("elija día 1 o 2: ")
    if dias == "1":
     nombre_paciente = input("por favor diga su nombre: ")
     while not nombre_paciente.isalpha():
      print("solo letras")
      nombre_paciente = input("por favor diga su nombre: ")
     nombre_paciente = nombre_paciente.lower()  
      
     if lunes1 == nombre_paciente:
      print(f"{nombre_paciente} ya tiene el turno 1 (lunes) asignado")
     elif lunes2 == nombre_paciente:
      print(f"{nombre_paciente} ya tiene el turno 2 (lunes) asignado")
     elif lunes3 == nombre_paciente:
      print(f"{nombre_paciente} ya tiene el turno 3 (lunes) asignado")
     elif lunes4 == nombre_paciente:
      print(f"{nombre_paciente} ya tiene el turno 4 (lunes) asignado")
 
 
     else :
      if lunes1 == "":
       lunes1 = nombre_paciente
       print(f"{nombre_paciente} fue asignado al turno 1 (lunes)")
      elif lunes2 == "":
       lunes2 = nombre_paciente
       print(f"{nombre_paciente} fue asignado al turno 2 (lunes)")
      elif lunes3 == "":
       lunes3 = nombre_paciente
       print(f"{nombre_paciente} fue asignado al turno 3 (lunes)")
      elif lunes4 == "": 
       lunes4 = nombre_paciente
       print(f"{nombre_paciente} fue asignado al turno 4 (lunes)")
      else:
       print("no hay turnos disponibles")   

    elif dias == "2":
     nombre_paciente = input("por favor diga su nombre: ")
     while not nombre_paciente.isalpha():
      print("solo letras")
      nombre_paciente = input("por favor diga su nombre: ")
     nombre_paciente = nombre_paciente.lower()   
     if martes1 == nombre_paciente:
      print(f"{nombre_paciente} ya tiene el turno 1 (martes) asignado")
     elif martes2 == nombre_paciente:
      print(f"{nombre_paciente} ya tiene el turno 2 (martes) asignado")
     elif martes3 == nombre_paciente:
      print(f"{nombre_paciente} ya tiene el turno 3 (martes) asignado")
   
     else :
      if martes1 == "":
       martes1 = nombre_paciente
       print(f"{nombre_paciente} fue asignado al turno 1 (martes)")
      elif martes2 == "":
        martes2 = nombre_paciente
        print(f"{nombre_paciente} fue asignado al turno 2 (martes)")
      elif martes3 == "":
       martes3 = nombre_paciente
       print(f"{nombre_paciente} fue asignado al turno 3 (martes)")
      else:
       print("no hay turnos disponibles")  

 
 
 elif opcion == "2":
    dias = input("elija el día a cancelar: 1/lunes o 2/martes ")
    while not dias.isdigit() or int(dias) < 1 or int(dias) > 2:
      print("opción invalida")
      dias = input("elija día 1 o 2: ")
     
    if dias == "1":
     nombre_paciente = input("por favor diga su nombre: ")
     while not nombre_paciente.isalpha():
       print("solo letras")
       nombre_paciente = input("por favor diga su nombre: ")
     nombre_paciente = nombre_paciente.lower() 
     
     if lunes1 == nombre_paciente:
        lunes1 = ""
        print(f"turno 1 del paciente {nombre_paciente} cancelado")

     elif lunes2 == nombre_paciente:
        lunes2 = ""
        print(f"turno 2 del paciente {nombre_paciente} cancelado")

     elif lunes3 == nombre_paciente:
        lunes3 = ""
        print(f"turno 3 del paciente {nombre_paciente} cancelado")

     elif lunes4 == nombre_paciente:
        lunes4 = ""
        print(f"turno 4 del paciente {nombre_paciente} cancelado")

     else:
        print("el paciente no tiene turno en lunes")

    elif dias == "2":
     nombre_paciente = input("por favor diga su nombre: ")
     while not nombre_paciente.isalpha():
       print("solo letras")
       nombre_paciente = input("por favor diga su nombre: ")
     nombre_paciente = nombre_paciente.lower() 
     
     if martes1 == nombre_paciente:
        martes1 = ""
        print(f"turno 1 del paciente {nombre_paciente} cancelado")

     elif martes2 == nombre_paciente:
        martes2 = ""
        print(f"turno 2 del paciente {nombre_paciente} cancelado")

     elif martes3 == nombre_paciente:
        martes3 = ""
        print(f"turno 3 del paciente {nombre_paciente} cancelado")

     else:
        print("el paciente no tiene turno en martes")    
 
 
 elif opcion == "3":
     dias = input("elija de que día quiere ver la agenda: 1/lunes o 2/martes ")
     while not dias.isdigit() or int(dias) < 1 or int(dias) > 2:
       print("opción invalida")
       dias = input("elija día 1 o 2: ")
     
     if dias == "1":
       print("AGENDA LUNES")

       if lunes1 == "":
        print("Turno 1: disponible")
       else:
        print(f"Turno 1: {lunes1}")

       if lunes2 == "": 
        print("Turno 2: disponible")
       else:
        print(f"Turno 2: {lunes2}")

       if lunes3 == "":
        print("Turno 3: disponible")
       else:
        print(f"Turno 3: {lunes3}")

       if lunes4 == "":
        print("Turno 4: disponible")
       else:
        print(f"Turno 4: {lunes4}")


     elif dias == "2":
       print("AGENDA MARTES")

       if martes1 == "":
        print("Turno 1: disponible")
       else:
        print(f"Turno 1: {martes1}")

       if martes2 == "": 
        print("Turno 2: disponible")
       else:
        print(f"Turno 2: {martes2}")

       if martes3 == "":
        print("Turno 3: disponible")
       else:
        print(f"Turno 3: {martes3}")

 elif opcion == "4":    
        ocupados_lunes = 0
        disponibles_lunes = 0
        ocupados_martes = 0
        disponibles_martes = 0
        if lunes1 == "":
         disponibles_lunes += 1
        else:
         ocupados_lunes += 1

        if lunes2 == "":
         disponibles_lunes += 1
        else:
         ocupados_lunes += 1

        if lunes3 == "":
         disponibles_lunes += 1
        else:
         ocupados_lunes += 1

         if lunes4 == "":
          disponibles_lunes += 1
         else:
          ocupados_lunes += 1
       
        print(f"lunes: tiene {ocupados_lunes} turnos ocupados y {disponibles_lunes} turnos disponibles")


        if martes1 == "":
         disponibles_martes += 1
        else:
         ocupados_martes += 1

        if martes2 == "":
         disponibles_martes += 1
        else:
         ocupados_martes += 1

        if martes3 == "":
         disponibles_martes += 1
        else:
         ocupados_martes += 1

        print(f"martes: tiene {ocupados_martes} turnos ocupados y {disponibles_martes} turnos disponibles") 



        if ocupados_lunes > ocupados_martes:
         print("Lunes tiene más turnos asignados")
        elif ocupados_martes > ocupados_lunes:
         print("Martes tiene más turnos asignados")
        else:
         print("Ambos días tienen la misma cantidad de turnos asignados")
 
 elif opcion == "5":
   print("salió del programa, muchas gracias")
   break