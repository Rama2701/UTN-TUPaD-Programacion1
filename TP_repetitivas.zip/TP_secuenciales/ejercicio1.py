nombre = input("diga el nombre del cliente: ")
while not nombre.isalpha():
 print("error, solo letras para el nombre")
 nombre = input("ingrese el nombre nuevamente: ")

cant_productos = input("ingrese la cantidad de productos: ")

while not cant_productos.isdigit() or int(cant_productos) <= 0  :
    print("error solo puede ingresar numeros enteros y positivos")
    cant_productos = input(" ingrese el numero ")
cant_productos = int(cant_productos)


total_con_descuentos = 0
sin_descuentos = 0
ahorro_total = 0
for i in range (1,cant_productos+1):
   precios = input("precio del producto ")
   
   while not precios.isdigit() or int(precios) <=0:
      print("ERROR SOLO NUMEROS ENTEROS Y POSITIVOS")
      precios = input("estableza el numero otra vez ")
 
   precios = int(precios)
   sin_descuentos += precios  
   
   descuento = input("tiene descuento? (s/n): ").lower()

   while descuento != "s" and descuento != "n":
      print("Error, ingrese 's' o 'n'")
      descuento = input("tiene descuento? (s/n): ").lower()   
   if descuento == "s" :
      monto_descuento = precios * 0.10
      precio_final = precios - monto_descuento
      total_con_descuentos += precio_final
      ahorro_total += monto_descuento
   else :
      precio_final = precios
      total_con_descuentos += precios
  
   promedio = total_con_descuentos / cant_productos
  
print(f"Total sin descuentos: ${sin_descuentos}")
print(f"Total con descuentos: ${total_con_descuentos:.2f}")
print(f"Ahorro: ${ahorro_total:.2f}")
print(f"Promedio por producto: ${promedio:.2f}")